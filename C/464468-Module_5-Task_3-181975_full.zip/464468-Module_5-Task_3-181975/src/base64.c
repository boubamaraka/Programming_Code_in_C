#include "base64.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* The set of base64-encoded characters. You may use this table if you want.
 * (The last character is not part of the actual base64 set, but used for
 * padding). 
 */
const char *encoding = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";


/* Open file named <src_file> for reading, and convert it to Base64 format,
 * which is written to file named <dst_file>.
 * 
 * Returns: number of bytes in <src_file>, or -1 if there was an error,
 * for example if opening of <src_file> did not succeed.
 */
int to_base64(const char *dst_file, const char *src_file)

{
    FILE *file1 = fopen(src_file, "r");
    FILE *file2 = fopen(dst_file, "w");
    if (file1==NULL || file2==NULL) {
        return -1;
    }
    int counter=0;
    int val=fgetc(file1);
    while(val!=EOF)
    {
        counter++;
        val=fgetc(file1);
    }
    fseek(file1,0,SEEK_SET);
    char str;  
    int ccount = 0;
    int upcount = 0;
    int counter1 = 0;
   
    unsigned char older;
    while (upcount == 0) {
        unsigned char src[3] = {0};
        unsigned char dest[4] = {0};
        int x = 0;
        while ( x < 3) {
            if ((str = getc(file1)) != EOF) {
                src[x] = str;
                counter1++;
            } else {
                for (int k = x; k < 3; k++) {
                    upcount++;
                }
                break;
            }
            x++;
        }
        if (upcount == 3) {
            break;
        }
        dest[0] = src[0] >> 2;
        older = ((src[0] << 6) + (src[1] >> 2));
        dest[1] = older >> 2;
        older = ((src[1] << 4) + (src[2] >> 4));
        dest[2] = older >> 2;
        dest[3] = src[2] & 63;
        int y = 0; 
        while (y < 4 - upcount) {
            if (ccount == 64) {
                fputc('\n', file2);
                ccount = 0;
            }
            fputc(encoding[(int)dest[y]], file2);
            ccount++;
            y++;
        }
        for (int j = 0; j < upcount; j++) {
            fputc('=', file2);
        }
    }
    fclose(file1);
    fclose(file2);
    return counter;
}
/* Open Base64-encoded file named <src_file> for reading, and convert it
 * to regular binary format, which is written to file named <dst_file>.
 * 
 * Returns: number of bytes in <src_file>, or -1 if there was an error,
 * for example if opening of <src_file> did not succeed.
 */
int from_base64(const char *dst_file, const char *src_file)
{
FILE *file1 = fopen(src_file, "r");
    FILE *file2 = fopen(dst_file, "w");
    if (file1==NULL || file2==NULL) {
        return -1;
    }
    int counter = 0;
    int upcounter = 0;
    char str;
   do {
        unsigned char dest[4] = {0};
        unsigned char src[3] = {0};
        int x = 0;
        while ( x < 4) {
            if ((str = getc(file1)) != EOF) {
                if (str == '\n') {
                    x--;
                } else if (str== '=') {
                    upcounter++;
                }
                src[x] = str;
                counter++;
            } else {
                upcounter = 3;
            }
            x++;
        }
        if (upcounter == 3) {
            break;
        }
        int j = 0;
        while( j < 4) {
            src[j] = &(*strchr(encoding, src[j])) - encoding;
            j++;
        }
        dest[0] = (src[0] << 2) + ((src[1] >> 4) & 3);
        dest[1] = (src[1] << 4) + (src[2] >> 2);
        dest[2] = (src[2] << 6) + src[3];
 
        for (int x = 0; x < 3 - upcounter; x++) {
            fputc(dest[x], file2);
        }
    } while (!feof(file1));
     
    fclose(file1);
    fclose(file2);
    return counter;
}
