int to_base64(const char *dst_file, const char *src_file);
int from_base64(const char *dst_file, const char *src_file);
