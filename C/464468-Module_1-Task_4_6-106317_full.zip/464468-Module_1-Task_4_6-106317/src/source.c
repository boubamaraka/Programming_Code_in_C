#include <stdio.h>
#include <math.h>
#include "source.h"


/* Exercise 1.4 */
void multi_table(unsigned int xsize, unsigned int ysize)
{
    int i,j;
    for(i=1;i<=ysize;i++){
           {

            for(j=1;j<=xsize;j++)
        printf("%4d",i*j);
           }
           printf("\n");
    }
}


/* Exercise 1.5 */
void draw_triangle(unsigned int size)
{
     int i,j,k;
    for(i=1;i<=size;i++){
        for(j=size-1;j>=i;j--)

          printf(".");
        for(k=1;k<=i;k++)
           {

            printf("#");}
            printf("\n");

    }

}

double distance(int x, int y)
{
    return sqrt(x * x + y * y);
}

/* Exercise 1.6 */
void draw_ball(int radius)
{
    
    int i,j;
   for(i=-radius;i<=radius;i++)
   {


          for(j=-radius;j<=radius;j++){
            if(distance(j,i)<=radius)
            printf("*");
          else printf(".");



   }
   printf("\n");

}
}

