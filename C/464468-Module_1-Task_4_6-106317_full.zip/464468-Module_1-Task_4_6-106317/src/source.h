#include <stdio.h>

void multi_table(unsigned int xsize, unsigned int ysize);
void draw_triangle(unsigned int size);
void draw_ball( int diam);
