#include "source.h"

int main()
{
    /* testing exercise 1.4 */
    printf("\n--- Exercise 1.4 ---\n");
    multi_table(4,5); 
    
    /* testing exercise 1.5 */
    printf("\n--- Exercise 1.5 ---\n");
    draw_triangle(5);
    
    /* testing exercise 1.6 */
    printf("\n--- Exercise 1.6 ---\n");
    draw_ball(3);
        
    return 0;
}
