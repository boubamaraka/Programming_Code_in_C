#include <stdlib.h>
#include <stdio.h>
#include "gameoflife.h"


/* Exercise 4.2.a: Allocates needed memory for the field structure and
 * the actual game field. 'xsize' and 'ysize' indicate the horizontal and
 * vertical dimensions of the field.
 * 
 * Returns: pointer to the Field structure allocated by this function.
 */
Field *createField(unsigned int xsize, unsigned int ysize)
{
    
    Field *or =malloc(sizeof(Field));
    unsigned int j,i;
    or->xsize=xsize;
    or->ysize=ysize;
      or->cells=malloc(ysize* sizeof(State *));
    for(i=0;i<ysize;i++){
       or->cells[i]=malloc(xsize* sizeof(State));
        
      for(j=0;j<xsize;j++){
       or->cells[i][j]=DEAD;
        }
    }
    return or;   // replace this
}

/* Free memory allocated for field <f>.
 */
void releaseField(Field *f)
{   unsigned int k;
    unsigned int  i=f->ysize;
    for(k=0;k<i;k++)
        free(f->cells[k]);
    free(f->cells);
    free (f);
}

/* Exercise 4.2.b: Initialize game field by setting exactly <n> cells into
 * ALIVE state in the game field <f>.
 */
void initField(Field *f, unsigned int n)
{
    (void) f;
    (void) n;
    unsigned int i,j;
    for(i=0;i<f->ysize;i++){
         for(j=0;j<f->xsize;j++){
             if(n>0){
             f->cells[i][j]=ALIVE;
             n--;
             }
             else{ break;
             }
         }
        
    }
   
    
    
    
}

/* Exercise 4.2.c: Output the current state of field <f>.
 */
void printField(const Field *f)
{
    (void) f;
    unsigned i,j;
    for(i=0;i<f->ysize;i++){
        for(j=0;j<f->xsize;j++){
            if(f->cells[i][j]==ALIVE)
                f->cells[i][j]='*';
                else
                    f->cells[i][j]='.';
                    
        }
    
    }
    for(i=0;i<f->ysize;i++){
        for(j=0;j<f->xsize;j++){
            printf("%c",f->cells[i][j]);
        
        }
        printf("\n");
    }
}

int fieldborder(Field *new, int newrow, int newcol)
{
    int val1, x1, val2,y1;
     int cell = 0;
     int value1,value2;
    x1 = new->xsize;
    y1 = new->ysize;
    val1=-1; 
    while(val1 < 2)
    {  val2=-1;
        while( val2< 2)
        {
            value1= newcol + val2;
            value2 = newrow + val1;
            if((val1 != 0 || val2!= 0)&& value1 < x1 && value1 >= 0 && value2 < y1 && value2 >= 0 && new->cells[value2][value1]==ALIVE)
            
            {
                cell++;
            } 
            val2++;
        }
        val1++;
    }
    return cell;
}




/* Exercise 4.2.d: Advance field <f> by one generation.
 */
void tick(Field *f)
{
    (void) f;
   unsigned int i,j; int counter;
       unsigned int row, col;
    
    Field *newfield = malloc(sizeof(Field));
    newfield->xsize = f->xsize;
    newfield->ysize = f->ysize;
    newfield->cells = malloc(newfield->ysize * sizeof(State*));
    row=0;
    while(row < newfield->ysize)
    {
        newfield->cells[row] = malloc(newfield->xsize * sizeof(State));
        col=0;
        while(col < newfield->xsize)
        {
            newfield->cells[row][col] = f->cells[row][col];
            col++;
        }
        row++;
    }

    for(i=0;i<newfield->ysize;i++){
        
        for(j=0;j<newfield->xsize;j++)
        { counter= fieldborder(newfield,i,j);
             if(counter > 3 && (newfield->cells[i][j] == ALIVE))
                f->cells[i][j] = DEAD;
             else  if((counter==2 || counter==3)&& (newfield->cells[i][j] == ALIVE))
                f->cells[i][j]=ALIVE;
             else if((counter==3)&&(newfield->cells[i][j] == DEAD))
                f->cells[i][j]=ALIVE;
             else if (counter == 0 || counter == 1)
                f->cells[i][j] = DEAD;

            
                        
        }
        
        
    
    }
    releaseField(newfield);
  
}

