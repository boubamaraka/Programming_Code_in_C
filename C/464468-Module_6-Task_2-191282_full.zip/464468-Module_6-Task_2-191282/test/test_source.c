#include <check.h>
#include "tmc-check.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "../src/getopt.h"

#define NumTries 3
#define MaxOpts 10

void randString(char *work, int len)
{
    for (int i = 0; i < len; i++) {
        char c = rand() % ('z' - 'a') + 'a';
        work[i] = c;
    }
    work[len] = 0;
}

void rand_cmdline(char *opts, char **optarg, char **args, int *argc)
{
    int n = (rand() & 7) + 2;
    int ac = 1;
    strcpy(args[0], "xxx");
    
    for (int i = 0; i < n; i++) {
        char c = 0;
        do {
            c = 'a' + (rand() % ('z' - 'a'));
            for (int j = 0; j < i; j++) {
                if (opts[j] == c)
                    c = 0;
            }
            opts[i] = c;
        } while(!c);
    }
    
    for (int i = 0; i < n; i++) {
        sprintf(args[ac], "-%c", opts[i]);
        
        if (rand() & 1) {
            ac++;
            randString(args[ac], 8);
            optarg[i] = args[ac];
        } else {
            optarg[i] = NULL;
        }
        ac++;
    }
    *argc = ac;
}

void print_cmdline(char *buf, int argc, char **argv)
{
    *buf = 0;
    for (int i = 0; i < argc; i++) {
        strcat(buf, argv[i]);
        strcat(buf, " ");
    }
}

START_TEST(test_get_options) {
    char argvec[MaxOpts * 2][20];
    char *args[MaxOpts * 2];
    int argc;
    char opts[MaxOpts] = { 0 };
    char *optarg[MaxOpts] = { NULL };
    
    for (int i = 0; i < NumTries; i++) {
        for (int j = 0; j < MaxOpts; j++) {
            opts[j] = 0;
            args[j*2] = argvec[j*2];
            args[j*2+1] = argvec[j*2+1];
        }
        rand_cmdline(opts, optarg, args, &argc);

        char cmdline[100];
        print_cmdline(cmdline, argc, args);
        
        struct options *opt = get_options(argc, args);
        if (!opt) {
            fail("[Task 6.2.a] get_options returned NULL");
        }

        struct options *orig = opt;
        for (int j = 0; j < MaxOpts; j++) {
            if (!opts[j])
                break;
            if (!opt) {
                free_options(orig);
                fail("[Task 6.2.a] Command line: \"%s\", premature NULL pointer at %d. member of linked list",
                        cmdline, j+1);
            }
            if (opt->optchar != opts[j]) {
                char oc[2] = { 0 };
                oc[0] = opt->optchar;
                remove_nonascii(oc);
                free_options(orig);
                fail("[Task 6.2.a] Command line: \"%s\", optchar member of structure is '%c' (%d), expected '%c'",
                        cmdline, oc[0], oc[0], opts[j]);
            }
            opt = opt->next;
        }
        free_options(orig);
    }
}
END_TEST

START_TEST(test_get_optarg)
{
    char argvec[MaxOpts * 2][20];
    char *args[MaxOpts * 2];
    int argc;
    char opts[MaxOpts] = { 0 };
    char *optarg[MaxOpts] = { NULL };
    
    for (int i = 0; i < NumTries; i++) {
        for (int j = 0; j < MaxOpts; j++) {
            opts[j] = 0;
            args[j*2] = argvec[j*2];
            args[j*2+1] = argvec[j*2+1];
        }
        rand_cmdline(opts, optarg, args, &argc);

        char cmdline[100];
        print_cmdline(cmdline, argc, args);

        struct options *opt = get_options(argc, args);
        if (!opt) {
            fail("[Task 6.2.b] get_options returned NULL");
        }
        for (char tc = 'a'; tc <= 'z'; tc++) {
            int ret = is_option(opt, tc);
            int sol = 0;
            for (int i = 0; i < MaxOpts; i++) {
                if (opts[i] == tc) {
                    sol = 1;
                    break;
                }
            }
            if (ret != sol) {
                free_options(opt);
                fail("[Task 6.2.b] Command line: \"%s\", is_option(opt, '%c') returned %d, expected %d",
                        cmdline, tc, ret, sol);
            }
            
            char *ret2 = get_optarg(opt, tc);
            char *sol2 = NULL;
            for (int i = 0; i < MaxOpts; i++) {
                if (opts[i] == tc) {
                    sol2 = optarg[i];
                    break;
                }
            }
            if (!sol2 && ret2) {
                free_options(opt);
                fail("[Task 6.2.b] Command line: \"%s\", get_optarg(opt, '%c') returned non-null value, but expected NULL",
                        cmdline, tc);  
            }
            if (sol2 && !ret2) {
                free_options(opt);
                fail("[Task 6.2.b] Command line: \"%s\", get_optarg(opt, '%c') returned NULL, but expected non-null value",
                        cmdline, tc);                  
            }
            if (sol2 && strncmp(sol2, ret2, 20)) {
                remove_nonascii(ret2);
                free_options(opt);
                fail("[Task 6.2.b] Command line: \"%s\", get_optarg(opt, '%c') returned \"%s\", but expected \"%s\"",
                        cmdline, tc, ret2, sol2);                      
            }
        }
        free_options(opt);
    }
}
END_TEST


#if 0
void randString(char *work, char *rev, int len)
{
    for (int i = 0; i < len; i++) {
        char c = rand() % ('z' - 'a') + 'a';
        work[i] = c;
        rev[len-1-i] = c;
    }
    work[len] = 0;
    rev[len] = 0;
}

START_TEST(test_turn_around) {
    char workStr[5][20] = { "testi", "sokos", "toimii", "0123456789abcdef", "" };
    char origStr[5][20];
    char revStr[5][20] = { "itset", "sokos", "iimiot", "fedcba9876543210", "" };
    randString(workStr[4], revStr[4], 10);
    memcpy(origStr, workStr, sizeof(origStr));
    for (int i = 0; i < 5; i++) {
        turn_around(workStr[i]);
        if (strlen(workStr[i]) > 19) {
            fail("[Task 6.1.a] Produced string is too long. You might have forgot trailing '\0'");
        }
        if (strcmp(workStr[i], revStr[i])) {
            fail("[Task 6.1.a] Reversing string '%s' should result '%s'. You produced: '%s'",
                    origStr[i], revStr[i], workStr[i]);
        }
    }
}
END_TEST

void randPal(char *work)
{
    for (int i = 0; i < 5; i++) {
        char c = rand() % ('z' - 'a') + 'a';
        work[i] = c;
        work[9-i] = c;
    }
    work[10] = 0;
}

START_TEST(test_is_reversed) {
    char workStr[5][20] = { "testi", "sokos", "soimii", "saippuakauppias", "" };
    int corRes[5] = { 0, 1, 0, 1, 1 };
    randPal(workStr[4]);
    for (int i = 0; i < 5; i++) {
        int res = is_reversed(workStr[i]);
        if (res != corRes[i]) {
            fail("[Task 6.1.a] Should return %d for string '%s'. You returned %d",
                    corRes[i], workStr[i], res);
        }
    }
}
END_TEST



START_TEST(test_reversed_words) {
    char *workStr[3];
    for (int i = 0; i < 3; i++) {
      workStr[i] = calloc(1, 200);
    }
    strcpy(workStr[0], "Small string to be reversed");
    strcpy(workStr[1],  "A palindrome is a word,\n"
        "phrase, number, or other sequence of\n"
	   "symbols or elements.\n");

    /*    char workStr[3][200] = { "Small string to be reversed",
        "A palindrome is a word,\n"
        "phrase, number, or other sequence of\n"
        "symbols or elements.\n" }; */
    char origStr[3][200];
    char revStr[3][200] = { "llamS gnirts ot eb desrever",
        "A emordnilap si a drow,\n"
        "esarhp, rebmun, ro rehto ecneuqes fo\n"
        "slobmys ro stnemele.\n" };
    
    int count = 2;
    
    for (int i = 0; i < 3; i++) {
      memcpy(origStr[i], workStr[i], 200);
    }

    for (int i = 0; i < count; i++) {
        reversed_words(workStr[i]);
        if (strlen(workStr[i]) > 199) {
	    for (int i = 0; i < 3; i++) {
	        free(workStr[i]);
	    }
            fail("[Task 6.1.c] Produced string is too long. You might have forgot trailing '\0'");
        }
        if (strcmp(workStr[i], revStr[i])) {
	  char buf[400];
	  sprintf(buf, "[Task 6.1.c] Reversing string '%s' should result '%s'. You produced: '%s'",
		  origStr[i], revStr[i], workStr[i]);
	  for (int i = 0; i < 3; i++) {
	      free(workStr[i]);
	  }
	  fail(buf);
        }
    }
    for (int i = 0; i < 3; i++) {
        free(workStr[i]);
    }
}
END_TEST

void random_str(char *str, char *common) {
    char words[5][8];
    str[0] = 0;
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 6; j++) {
            words[i][j] = rand() % ('z' - 'a') + 'a';
        }
        words[i][6] = 0;
    }
    int com = rand() % 5;
    int loc = rand() % 5;
    for (int i = 0; i < 5; i++) {
        if (loc == i) {
            strcat(str, words[com]);
            strcat(str, " ");
        }
        strcat(str, words[i]);
        strcat(str, " ");
    }
    strcpy(common, words[com]);
}

START_TEST(test_most_common) {
    char test[3][50] = { "one two one three two four two",
    "aaa bbb bbb bbb bbb ccc ccc ccc", "" };
    char modres[3][8] = { "two", "bbb", "" };
    int retval[3] = {3, 4, 2};
    
    random_str(test[2], modres[2]);
    
    for (int i = 0; i < 3; i++) {
        char result[10];
        result[0] = 0;
        int ret = most_common(test[i], result, 10);
        if (ret != retval[i]) {
            fail("[Task 6.1.d] With string '%s' should return %d. You returned %d",
                    test[i], retval[i], ret);
        }
        if (strcmp(modres[i], result)) {
            fail("[Task 6.1.d] With string '%s' the most common string is '%s'. You returned '%s'",
                    test[i], modres[i], result);
        }
    }
}
END_TEST
#endif

int main(int argc, const char *argv[]) {
    srand((unsigned)time(NULL));
    Suite *s = suite_create("Test-6.2");

    tmc_register_test(s, test_get_options, "6.2.a");
    tmc_register_test(s, test_get_optarg, "6.2.b");

    return tmc_run_tests(argc, argv, s);
}
