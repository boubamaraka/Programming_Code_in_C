#include <stdlib.h>
#include <stdio.h>
#include "getopt.h"
#include <ctype.h>
#include <string.h>

/* [6.2.a] Returns the list of options given on command line arguments
 * indicated in <argc> and <argv>. These parameters are used similarly as
 * in the main function.
 *
 * Function returns pointer to the start of linked list that contains the
 * options.
 */
struct options *get_options(int argc, char *argv[]) {

    int counter=1;
    struct options *end;
    struct options *begin;
    begin = malloc(sizeof (struct options));
    end = begin;
    while( counter < argc) {
        struct options *area;
        if (argv[counter][0] == '-') {

            if (isalpha(argv[counter][1]) != 0) {
                area= malloc(sizeof (struct options));
                area->optchar = argv[counter][1];
                end->next = area;
                end = area;
                area->next = NULL;
                 area->optarg=NULL;
                
            }
            if (counter + 1 < argc) {
                if (argv[counter + 1][0] != '-') {
                    int len = strlen(argv[counter + 1]);
                    area->optarg = malloc((len + 1) * sizeof (char));
                    strcpy(area->optarg, argv[counter + 1]);
                    area->optarg[len] = '\0';
                    counter++;

                } 
            }

        }
        counter++;

    }
    struct options *newarea;
    newarea = begin->next;
    free(begin);
    return newarea;

}

/* [6.2.a] Free the memory allocated for the linked list at <opt>.
 */
void free_options(struct options *opt) {
    struct options *start = opt;
  do {
        struct options *new = start;
        start = start->next;
        free(new->optarg);
        free(new);
    } while (start);

}

/* [6.2.b] Returns non-zero if option character <optc> is included in the
 * linked list pointed by <opt>
 */
int is_option(struct options *opt, char optc) {
    struct options *start = opt;
do {
        if (start->optchar == optc) {
            return 1;
        }
        start = start->next;
    } while (start);
    return 0;
}

/* [6.2.b] Returns the argument given with option <optc>. If argument or
 * the option was not given, the function returns NULL.
 */
char *get_optarg(struct options *opt, char optc) {
    struct options *start = opt;
    if (!opt || !optc) {
        return NULL;
    } else {
do {
            if (start->optchar == optc) {
              return start->optarg;
            }
            start = start->next;
        } while (start);

    }
    return NULL;
}