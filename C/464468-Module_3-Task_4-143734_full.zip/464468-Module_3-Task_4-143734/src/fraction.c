#include <stdlib.h>
#include "fraction.h"
#include <stdio.h>

struct fraction_st {
    unsigned int x, y;
};

/* Algorithm for determining greatest common divisor, needed in Task 16.5 */
/* The function returns gcd between the two parameters, u and v */
/* Taken from http://en.wikipedia.org/wiki/Binary_GCD_algorithm */
unsigned int gcd(unsigned int u, unsigned int v)
{
    // simple cases (termination)
    if (u == v)
        return u;
 
    if (u == 0)
        return v;
 
    if (v == 0)
        return u;
 
    // look for factors of 2
    if (~u & 1) // u is even
    {
        if (v & 1) // v is odd
            return gcd(u >> 1, v);
        else // both u and v are even
            return gcd(u >> 1, v >> 1) << 1;
    }
 
    if (~v & 1) // u is odd, v is even
        return gcd(u, v >> 1);
 
    // reduce larger argument
    if (u > v)
        return gcd((u - v) >> 1, v);
 
    return gcd((v - u) >> 1, u);
}


/* Exercise 3.4.a: Set fraction
 * Parameters: numerator and denominator
 * Returns: pointer to allocated fraction
 *
 */


Fraction* setFraction(unsigned int numerator, unsigned int denominator)
{  
    Fraction *newf= malloc(sizeof(struct fraction_st));
   newf->x = numerator;
   newf->y = denominator;
    
    return newf;  // replace this
}

unsigned int getNum(const Fraction *f)
{
   
    return f->x;
}

unsigned int getDenom(const Fraction *f)
{
    
    return f->y;
    
}

void freeFraction(Fraction *f)
{
    free(f);
}


/* Exercise 3.4.b: Compare values
 * Parameters: two fractions to be compared
 * Returns:
 * -1 if a is smaller than b
 * 0 if the fractions are equal
 * 1 if a is larger than b
 */
int compFraction(const Fraction *a, const Fraction *b)
{   float a1= 1.0*(a->x);
    float a2= 1.0*(a->y);
    float b1= 1.0*(b->x);
    float b2= 1.0*(b->y);
    
    
    float v1=(a1/a2);
    float v2=(b1/b2);
    if(v1==v2)
        return 0;
        else if(v1>v2)
            return 1;
        else
            return -1;
    
    
    
    
        
}

/* Exercise 3.4.c: Add values
 * Parameters: two fractions to be added
 * Returns: sum of the fractions
 */
Fraction* addFraction(const Fraction *a, const Fraction *b)
{   Fraction *c = malloc(sizeof(struct fraction_st));
     c->x=(((a->x)*(b->y))+((b->x)*(a->y)));
     c->y=((a->y)*(b->y));
    return c;  // replace this
}


/* Exercise 3.4.e: Reduce fraction
 * Parameters: Fraction to be reduced. Reduction happens on the object itself */
void reduceFraction(Fraction* val)
{  (void) val;
    //Fraction *val2 = malloc(sizeof(struct fraction_st));
unsigned int bouba=gcd(val->x,val->y);
    val->x=val->x/bouba;
    val->y=val->y/bouba;
  
    
}

/* Not needed, but it will be useful to implement this */
void printFraction(const Fraction *val)
{   printf("%u / %u",val->x,val->y);
    (void) val;
}
