
void sort(int *start, int size);
int count_alpha(const char *str);
int count_substr(const char *str, const char *sub);
void korsoroi(char *dest, const char *src);

