#include <stdio.h>
#include <string.h>
#include "source.h"

int main()
{
    /* Testing 2.5: Sort. Implement a function to print
     * the resulting array to see that it really works */ 
    int arr[] = {3, 4, 7, 2, 8};
    sort(arr, 5);

    /* Testing 2.6: Count alpha */
    char *str = "How many alpha in this string?";
    printf("count_alpha: %d\n", count_alpha(str));

    /* Testing 2.7: Count substr */
    char str2[] = "one two one twotwo three";
    printf("count_substr: %d\n", count_substr(str2, "two"));
    
    /* Testing 2.8: Korsoroi */
    char buf[100], dest[200];
    do {
        fgets(buf, 100, stdin);
        korsoroi(dest, buf);
        printf("korsoroi: %s\n", dest);
    } while (strlen(buf) > 1);
    
    return 0;
}
