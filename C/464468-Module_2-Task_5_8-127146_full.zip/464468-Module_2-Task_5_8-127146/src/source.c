#include "source.h"
#include<ctype.h>
#include <string.h>


/* Exercise 2.5: Selection sort */
/* Parameters:
 * start: start of an array
 * size: length of an array
 */
void sort(int *start, int size)
{
    (void) start;
    (void) size;int j;
    int t;
    
    for(int i=0;i<size;i++)
    { for( j=0;j<size-1;j++)
        if(start[j]>start[j+1]){
            t=start[j];
    start[j]=start[j+1];
    start[j+1]=t;}
    
    
    }
    
}



/* Exercise 2.6: Count Alpha
 * Count number of alphabetic characters in the given string <str>,
 * and return the count
 */
int count_alpha(const char *str)
{
    (void) str;
    
    int result=0;
    int i=0;
    
    while(str[i]!='\0')
    { if(isalpha(str[i]))
        result++;
    i++;
    }
    return result;  // replace this
}


/* Exercise 2.7: Count Substring
 * Count number of occurances of substring <sub> in string <str>,
 * and return the count.
 */
int count_substr(const char *str, const char *sub)
{
    (void) str;
    (void) sub;
    
    int count=0;
   
    while(( str=strstr(str,sub))!=NULL)
    {
        str=str+strlen(sub);
        
        count++;
        
    }
    return count;  // replace this
}
      // replace this



/* Exercise 2.8: Korsoraattori
 */
void korsoroi(char *dest, const char *src)
{
    (void) dest;
    (void) src;
    
    int j,k=0,c=0,c1=0;
    int size=strlen(src);
    
    for(j=0;j<size;j++)
    {
        if(src[j]=='t')
        {
            if(src[j+1]=='s')
            {
                dest[k]='z';
                k++;
               j++;
            }
            else
            {
                dest[k]=src[j];
                k++;
            }
        }
        else if(src[j]=='k')
        {
            if(src[j+1]=='s')
            {
                dest[k]='x';
               k++;
             j++;
            }
            else
            {
                dest[k]=src[j];
                k++;
            }
        }
        else if(src[j]==' ')
        {
            dest[k]=' ';
            k++;
            
            char t1[7]="niinku";
            char t2[9]="totanoin";
            int i;
           c++;
            c1++;
           
            
            
            int t1len=strlen(t1);
            int t2len=strlen(t2);
            
            if(c==3)
            {
                for(i=0;i<t1len;i++)
                {
                    dest[k]=t1[i];
                    k++;
                }
                dest[k]=' ';
                k++;
           c=0;
            }
            else if(c1==4)
            {
                for(i=0;i<t2len;i++)
                {
                    dest[k]=t2[i];
                    k++;
                }
                dest[k]=' ';
                k++;   
                c1=0;
            }
        }
        else
        {
            dest[k]=src[j];
            k++;
        }
    }
    dest[k]='\0';
}