#include "source.h"
#include <stdio.h>
#include <string.h>
#include<stddef.h>


/* Exercise 2.9.a: Print string */
/* Parameters:
 * s: string to be printed */
void es_print(const char *s)
{
    (void) s;
    
    
    int i=strlen(s);
    
    for(int j=0;j<=i;j++){
        if(s[j]=='#')
            break;
        else
        printf("%c",s[j]);
       }
     
    
    
}

/* Exercise 2.9.b: String length */
/* Parameters:
 * s: string to be evaluated
 * Returns: length of the string */
unsigned int es_length(const char *s)
{
    (void) s;
    int i=0;
     while(s[i]!='#'){
        
        i++;
        
       }
    return i; // replace this
}

/* Exercise 2.9.c: String copy */
/* Parameters:
 * dst: buffer to which the new string is copied
 * src: original string
 * Returns: Number of characters copied
 */
int es_copy(char *dst, const char *src)
{
    (void) dst;
    (void) src;
    int i=strlen(src);
    int result=0;
    int c;
   
    for(int j=0;j<=i;j++){
        if(src[j]!='#'){
            dst[j]=src[j];
           
        result++;
        
        
        }
        else{
            dst[j]=' ';
            c=result;
            dst[j]='#';
            break;
          }
       
            
        
       }
    
    
     return c;// replace this
}

/* Exercise 2.9.d: String tokenizer */
/* Parameters:
 * s: string to be processed
 * c: character to be replaced by '#'
 * Returns: pointer to the character following the replaced character,
 *          NULL if end of string reached */
char *es_token(char *s, char c)
{
    (void) s;
    (void) c;
    
    int j=0;
    
     do 
    { if(s[j]==c){
        s[j]='#';
        j++;
        return s+j;
        break;
        }
    else
        j++;
    
        
    
    }while(s[j]!='#');
    return NULL; // replace this
}
