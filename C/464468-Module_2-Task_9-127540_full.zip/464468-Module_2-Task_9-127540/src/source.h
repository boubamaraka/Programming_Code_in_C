
void es_print(const char *s);
unsigned int es_length(const char *s);
int es_copy(char *dst, const char *src);
char *es_token(char *s, char c);
int es_demo(char *s, char c);
