#include <stdio.h>
#include <stdlib.h>
#include "ships.h"

const unsigned int xsize = 10;
const unsigned int ysize = 10;
const unsigned int shiplen = 3;

/* implement these functions */

/* Task 1.9.a: Place <num> ships on the game map.
 */
void set_ships(unsigned int num)
{
    (void) num;
    unsigned int sizea,sizeb;
    int i,dir,loc;
    
    for (i=0;i<num;i++){
        do
        { sizea=rand()%xsize;
          sizeb=rand()%ysize;
          dir=rand()%2;
          loc=place_ship(sizea,sizeb,dir);
          
        }while(loc!=1);
        
    }
}

/* Task 1.9.b: print the game field
 */
void print_field(void)
 {
    unsigned int i, j;
    int visible;
    char isVis;
    for (i = 0; i < xsize; i++) {
        for (j = 0; j < ysize; j++) {
            visible = is_visible(j, i);
            if (visible != 0) {
                isVis = is_ship(j, i);
                printf("%c", isVis);
            } else {
                printf("?");
            }

        }
        printf("\n");
    }
}


/* Task 1.9.c: Ask coordinates (two integers) from user, and shoot the location.
 * Returns -1 if user gave invalid input or coordinates, 0 if there was no ship
 * at the given location; and 1 if there was a ship hit at the location.
 */
int shoot(void)
{
    unsigned int var1,var2;
    char hit;
    //var1=rand()%10;
    //var2=rand()%10;
    scanf("%u %u",&var1,&var2);
    if (var1>=0 && var1<10 && var2>=0 && var2<10){
        hit=is_ship(var1,var2);
        checked(var1,var2);
        if(hit=='+')
        { hit_ship(var1,var2);
        return 1;
        }
        else{
        return 0; }
    
    }
    else {
        
        return -1;
    }
     // replace this
}

/* Task 1.9.d: Returns 1 if game is over (all ships are sunk), or 0 if there
 * still are locations that have not yet been hit. <num> is the number of
 * ships on the game map. It is assumed to be the same as in the call to
 * set_ships function.
 */
int game_over(unsigned int num)
{
    (void) num;
    unsigned int i,j;
    unsigned int counter;
    char hit;
    for(i=0;i<xsize;i++){
        for(j=0;j<ysize;j++){
            hit=is_ship(i,j);
            if(hit=='+'){
                return 0;
            }
            if(hit=='#')
                counter++;
            if(counter==(num*shiplen)){
                break;
                
            }
        }
    }
    return 1;  // replace this
}
