#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "polisher.h"

/* 6.1.a: Read given file <filename> to dynamically allocated memory.
 * Return pointer to the allocated memory with file content.
 */
char *read_file(const char *filename) {
    (void) filename;
    FILE *file;
    char *ch;

    char data;
    unsigned int i = 0;


    file = fopen(filename, "r");
    if (file == NULL) {

        return NULL;
    }
    ch = (char *) malloc(sizeof (char));

    while ((data = fgetc(file)) != EOF) {
        i++,

                ch = realloc(ch, (i + 1) * sizeof (char));

        ch[i - 1] = data;

    }
    ch[i] = '\0';
    fclose(file);

    return ch;
}

/* [6.1.b] Remove C comments from the program stored in memory block <input>.
 * Returns pointer to code after removal of comments.
 * Calling code is responsible of freeing only the memory block returned by
 * the function.
 */
char *remove_comments(char *input) {

    char* value;
    ;
    char *newpointer;

    int index = 0;

    value = NULL;
    newpointer = input;

    while (*input != '\0') {
        if (*input == '/' && *(input + 1) == '/') {
            input++;
            do {
                input++;
            } while (*input != '\n');
            input++;
        }// input++;
        else if (*input == '/' && *(input + 1) == '*') {
            input++;

            while (1) {
                input++;

                if ((*input == '*') && (*(input + 1) == '/')) {
                    break;
                }
            }
            input += 2;
        }


        value = (char*) realloc(value, ((index + 2) * sizeof (char)));
        value[index] = *input;
        input++;
        index++;
    }


    value[index] = '\0';

    free(newpointer);
    return value;
}

/* [6.1.c] Indent the C-code at memory block <indent>. String <pad> represents
 * one block of indentation. Only opening curly braces '{' increase the
 * indentation level, and closing curly braces '}' decrease the indentation level.
 * Return the pointer to the code after modification.
 * Calling code is responsible of freeing only the memory block returned by
 * the function.
 */
char *indent(char *input, const char *pad) {

    int brace = 0;
    int cbrace;
    int counter1;
    int counter2 = 0;

    int inputlen = strlen(input);
    int padlen = strlen(pad);
    char *value = malloc((inputlen + 1) * sizeof (char));
     counter1 = 0;
      while ( counter1 < inputlen) {
        if (input[counter1] == '{') {
            brace++;
        }
        if (input[counter1+1] == '}') {
            brace--;
        }
        value = realloc(value, (counter2 + (brace * padlen) + 15) * sizeof (char));
        value[counter2] = input[counter1];
        counter2 = counter2 + 1;
        if (input[counter1] == '\n' && input[counter1 + 1] != '\n') {

            cbrace = 0;
            while (cbrace != padlen * brace) {
                value[counter2] =*pad;
                counter2++;
                cbrace++;

            } 
            while (input[counter1 + 1] == '\t' || input[counter1 + 1] == ' ') {
                counter1++;

            } 
        }
  counter1++ ;

    }
    value[counter2] = '\0';
    free(input);

    return value;
}
