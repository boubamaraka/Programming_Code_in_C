title: Any data (3)
task_id: 4.1


**Objective:** Getting familiar with operating on unions.
	    
This exercise introduces a structured data type, **AnyData**, that can
hold either byte (i.e., char), integer or double value (note that the
structure is defined using `typedef`, and how it affects the type
usage in declarations). AnyData is a structured type that consists two
fields: **type** enumeration that indicates the actual type currently
stored on the structure, and **value** union that contains the actual
value in one of the above types. See **anydata.h** for the actual data
type definition. In addition, there is type 'UNDEF' that means value
does not contain any valid type.

4.1.a Set value
---------------

Implement functions **setByte**, **setInt** and **setDouble**
that will return a new AnyData object of given type, with value set as
indicated by the function parameter.

4.1.b Print value
-----------------

Implement function printValue, that will output the value of
AnyData. The output format depends on the type of value stored. For
outputting each particular type, you should use one of the output
functions given in 'anydata.c', depending on the actual AnyData type
(**printByte**, **printInt**, or **printDouble**).

4.1.c Calculate sum
-------------------

Implement function **calcSum** that calculates the sum of array of
AnyData objects. There are two arguments in the function call:
'**first**' points to the beginning of the array, and '**last**'
points to the last object in the array. The function should therefore
process all array elements between 'first' and 'last'
(inclusively). The function returns new AnyData object that contains
the sum.

The actual type of the sum must remain as "small" as possible: If all
array members are BYTE, the sum must remain BYTE. If the array
elements contain INTs or BYTEs, but no DOUBLEs, the sum must be
INT. If there are any DOUBLE type values, the sum must be DOUBLE. If
the array contains UNDEF values, they should be just ignored. You do
not need to consider whether e.g. a DOUBLE value could be represented
as INT without data loss, and you don't need to consider the case
where a sum of two BYTEs (or INTs) could overflow unless converted to
larger type. The enumeration stores the type identifiers in the order
of size, which may be helpful in your implementation.
