#include <stdio.h>
//#include <string.h>
#include "anydata.h"


/* Exercise 4.1.a functions
 * Return a new AnyData object based on the given input
 */
AnyData setDouble(double value)
{
    (void) value; // replace these lines with your code
    AnyData ad;
    ad.type = DOUBLE;
    ad.value.dval=value;
    return ad;
}

AnyData setInt(int value)
{
    (void) value; // replace these lines with your code
    AnyData ad;
    ad.type = INT;
    ad.value.ival=value;
    return ad;
}

AnyData setByte(char value)
{
    (void) value; // replace these lines with your code
    AnyData ad;
    ad.type = BYTE;
    ad.value.bval=value;
    return ad;
}


void printDouble(double val)
{
    printf("D:%lf", val);
}

void printInt(int val)
{
    printf("I:%d", val);
}

void printByte(char val)
{
   
    printf("B:%d", val);
}

/* Exercise 4.1.b:
 * Print the given AnyData value, using one of the above functions
 */
void printValue(AnyData val)
{
   (void) val; // replace these lines with your code
   switch(val.type) {
        case DOUBLE:
            printDouble(val.value.dval);
            break;
        case BYTE:
            printByte(val.value.bval);
            break;
        case INT:
            printInt(val.value.ival);
            break;
        case UNDEF:
            printf("--\n");
            break;
        }
}



/* Exercise 4.1.c:
 * calculate sum between array of AnyData objects.
 * first points to the first member of the array
 * last points to the last member of the array
 * 
 * Returns the sum as AnyData object. Must be as "small" data type as possible.
 */
AnyData calcSum(AnyData *first, AnyData *last)
{
    (void) first;  // replace these lines with your code
    (void) last;
    AnyData array;
   
    array.type = UNDEF;
    array.value.bval=0;
    array.value.ival=0;
    array.value.dval=0;
    while(first<=last){ 
        switch(first->type) {
        case DOUBLE:
          if(array.type==BYTE)
                    array.value.dval=array.value.bval;
                else if(array.type==INT)
                {array.value.dval=array.value.ival;
                array.type=DOUBLE;
                array.value.dval=array.value.dval + first->value.dval;}
                break;
        case BYTE:
        if(array.type==DOUBLE)
                 {
                 array.value.dval=array.value.dval + first->value.bval;
                 }
              else if(array.type==INT)
                 {
                 array.value.ival=array.value.ival + first->value.bval;
                 }
              else
                {
                 array.type=BYTE;
                 array.value.bval=array.value.bval + first->value.bval;
                 }
              break;
        case INT:
         if(array.type==DOUBLE)
                 {
                 array.value.dval=array.value.dval + first->value.ival;
                 }
              else if(array.type==BYTE)
                 {
                   array.value.ival=array.value.bval;
                   array.type=INT;
                   array.value.ival=array.value.ival + first->value.ival;
                 }
              else
                 {
                   array.type=INT;
                   array.value.ival=array.value.ival + first->value.ival;
                 }
                  
               break;
        case UNDEF:
            
            break;
        }
        
      first++;  
    }
    
    
    return array;
}

