#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "filestats.h"


/* Returns the line count in given file
 * 
 * Parameters:
 * filename: name of the file to be investigated.
 * 
 * Returns:
 * The number of lines in file. */
int line_count(const char *filename)
{
    (void) filename;
    FILE *file;
    char ch;
    int countline;
    int num=0;
   
    file = fopen(filename, "r");
    if (file==NULL) {
         
        return  -1;
    } 
    
   
    else{ch = fgetc(file);   
    countline=0;
        while ( ch!=EOF) {
          if(isalnum(ch))
            num++;
            if(isspace(ch))   
            {if(ch=='\n')
            countline++;
            num=0;
            }
       
        ch = fgetc(file); }
    if(num>0)
    countline++;}
    return countline;
}


/* Count the number of words in the file. Word has to include at least one
 * alphabetic character, and words are separated by whitespace.
 * 
 * Parameters:
 * filename: name of the file to be investigated.
 * 
 * Returns:
 * number of words in the file */
int word_count(const char *filename)
{
    (void) filename;
    
   FILE *file;
    char ch;
    int countword;
    int num=0;
   
    file = fopen(filename, "r");
    if (file==NULL) {
         
        return  -1;
    } 
    
   
    else{ch = fgetc(file);   
    countword=0;
       while ( ch!=EOF) {
          if(isalpha(ch))
            num++;
            if(isspace(ch))   
            {if(num>0)
            countword++;
            num=0;
            }
       
        ch = fgetc(file); }
    }
    if(num>0)
    countword++;
    
    return countword;
}
