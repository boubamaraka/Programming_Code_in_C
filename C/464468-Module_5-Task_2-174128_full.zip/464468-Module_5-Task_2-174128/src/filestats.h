int line_count(const char *filename);
int word_count(const char *filename);
