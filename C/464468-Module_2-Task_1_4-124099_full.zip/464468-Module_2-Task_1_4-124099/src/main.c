#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <string.h>
#include "source.h"

int main()
{
	/* This is an example for testing your functions.
	 * feel free to modify this code. TMC will not test this. */
    /* Lets first test 2.1 Pointer Sum with two input parameters */
    int val1 = 4; int val2 = 5;
    number_swap(&val1, &val2);
    if (val1 == 5) {
        printf("Great, 2.1 worked!\n");
    } else {
        printf("Invalid result for 2.1\n");
    }

    /* Testing 2.2 Extending Pointer sum */
    int valarray[] = { 10, 100, 1000 };
    int sum = array_sum(valarray, 3);
    if (sum == 1110) {
        printf("2.2 worked\n");
    } else {
        printf("Invalid result for 2.2");
    }

    /* Test 2.3 Array Reader */
    int ints[10];
    printf("Read %d integers!\n", array_reader(ints, 10));

    /* Test 2.4 Mastermind */
    int sol[6], guess[6];
    char result[7];
    srand((unsigned) time(NULL));
    for (int i = 0; i < 6; i++) {
        sol[i] = rand() % 10;
        // uncomment below, if you want to cheat (or test)
        printf("%d ", sol[i]);
    }
    unsigned int attempts = 10;
    do {
        printf("\nAttempts remaining: %d -- give 6 numbers: ", attempts);
        for (int i = 0; i < 6; i++)
            scanf("%d", &guess[i]);
        mastermind(sol, guess, result, 6);
        result[6] = 0;
        printf("  Result: %s", result);
    } while (attempts-- && strcmp(result, "++++++"));

    return 0;
}
