#include <stdio.h>
#include "source.h"


/* Exercise 2.1: Number swap
 * Swap the content of integers add addresses a and b
 */
void number_swap(int *a, int *b)
{
    (void) a;
    (void) b;
    int c=*a;
    *a=*b;
    *b=c;
    
}

/* Exercise 2.2: Array Sum
 * Calculate the sum of integers in array starting at address <array>.
 * There will be <count> elements in array. Return the sum as return value.
 */
int array_sum(int *array, int count)
{
    (void) array;
    (void) count;
    int *p=array;
    int sum=0;
   
    for(int i=1;i<=count;i++){
        sum =sum + *p;
        p++;
    }
       
    
    return sum;  // placeholder, replace with actual code
}

/* Exercise 2.3: Array Reader */
/* Parameters:
 * vals: array to be filled 
 * n: maximum size of array
 * returns: number of values read */
int array_reader(int *vals, int n)
{
    (void) vals;
    (void) n;
    int c=0,i,a;
   for(i=0;i<n;i++)
    {
         while(scanf("%d ",&a))
        {
          vals[i]=a;
            c=i+1;
            break;
        }
    }
    return c;  // placeholder, replace with actual code
}

/* Exercise 2.4: Mastermind
 */
void mastermind(const int *solution, const int *guess, char *result, unsigned int len)
{
    (void) solution;
    (void) guess;
    (void) result;
    (void) len;
     int i,j;
  
    for(i=0;i<(int)len;i++){
        for(j=0;j<(int)len;j++)
        {
        if(guess[i]!=solution[j])
        {
            if(j==(int)len-1&&result[i]!='*')
             result[i]='-';
        }
        else{{ 
            if(i==j)
            {result[i]='+';
            break;
              }
            else
                result[i]='*';
              }
        }
        }
       
        
        
             
        
    }
        
                        
            
                   
            
            
    }
