void number_swap(int *a, int *b);
int array_sum(int *array, int count);
int array_reader(int *vals, int n);
void mastermind(const int *solution, const int *guess, char *result, unsigned int len);

