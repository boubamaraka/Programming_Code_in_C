#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include<ctype.h>
#include "strarray.h"

/* Exercise 4.3.a: Initializes the string array to contain the initial
 * NULL pointer, but nothing else.
 * Returns: pointer to the array of strings that has one element
 *      (that contains NULL)
 */
char **init_array(void) {


    char** array;
    array = malloc(sizeof (array));
    array[0] = NULL;


    return array; // replace this
}

/* Releases the memory used by the strings.
 */
void free_strings(char **array) {
    (void) array; // replace this
    int j;
    for (j = 0; array[j] != NULL; j++) {
        free(array[j]);

    }
    free(array[j]);
    free(array);

}

/* Exercise 4.3.b: Add <string> to the end of array <array>.
 * Returns: pointer to the array after the string has been added.
 */
char **add_string(char **array, const char *string) {
    int length = strlen(string);

    int i = 0;
    while (array[i] != NULL)
        i++;
    array = realloc(array, (i + 2) * sizeof (char*));
    array[i] = malloc((length + 1) * sizeof (char));
    array[i + 1] = NULL;



    memcpy(array[i], string, length);
    array[i][length] = '\0';

    return array;
    // replace this
}

/* Exercise 4.3.c: Convert letters of all strings in <array> to lower case.
 */
void make_lower(char **array) {
    (void) array; //replace this
    int i = 0;
    int j;
    char c;
    while (array[i] != NULL) {
        for (j = 0; array[i][j] != '\0'; j++) {
            c = (char) array[i][j];

            array[i][j] = (tolower((int) c));

        }
        i++;
    }
}

/* Exercise 4.3.d: reorder strings in <array> to lexicographical order */
void sort_strings(char **array) {
    (void) array;

    unsigned int i = 0;
    unsigned int j;
     int c;
    unsigned int k;
    

    while (array[i] != NULL) {
        i++;
    }
    for (k = 0; k < i; k++) {
        for (j = 0; j < i - 1; j++) {
            c = strcmp(array[j], array[j + 1]);
            if (c > 0) {
                char *t;
                t = array[j];
                array[j] = array[j + 1];
                array[j + 1] = t;
            }
        }
    }



}

/* You can use this function to check what your array looks like.
 */
void print_strings(char **array) {
    if (!array)
        return;
    while (*array) {
        printf("%s  ", *array);
        array++;
    }
    printf("\n");
}
