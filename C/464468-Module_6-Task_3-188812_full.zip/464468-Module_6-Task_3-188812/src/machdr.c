#include "machdr.h"

/* 6.3.a: Implement all get_* functions. <header> points to the start of the
 * MAC header. The functions return the value of the respective field.
 * For flags, any non-zero return value indicates that flag is set, and zero
 * means it is not set.
 */

int get_proto_version(const unsigned char *header)
{
    (void) header;
    return *(header+0)>>6;
}

int get_type(const unsigned char *header)
{
    (void) header;
    return *(header+0)>>4 & 0b11;
}

int get_subtype(const unsigned char *header)
{
    (void) header;
    return *(header+0) & 0b1111; 
}

int get_to_ds(const unsigned char *header)
{
    (void) header;
    return  *(header+1)>>7;
}

int get_from_ds(const unsigned char *header)
{
    (void) header;
    return *(header+1)>>6 & 0b1;
}

int get_retry(const unsigned char *header)
{
    (void) header;
    return  *(header+1)>>4 & 0b1;
}

int get_more_data(const unsigned char *header)
{
    (void) header;
    return *(header+1)>>2 & 0b1; 
}

/* 6.3.b: Implement all set_* functions that set the values of respective
 * fields in the MAC header. <header> points to the start of the header,
 * and the second parameter indicates the value to be set.
 */

void set_proto_version(unsigned char *header, int version)
{
    (void) header;
    (void) version;
   * (header+0)= header[0] | version<<6 ;
}

void set_type(unsigned char *header, int type)
{
    (void) header;
    (void) type;
     * (header+0)= header[0] | type<<4 ;
}

void set_subtype(unsigned char *header, int subtype)
{
    (void) header;
    (void) subtype;
     * (header+0)= header[0] | subtype ;
}

void set_to_ds(unsigned char *header, int flag)
{
    (void) header;
    (void) flag;
    *(header+1)=flag<<7 | *(header+1);
}

void set_from_ds(unsigned char *header, int flag)
{
    (void) header;
    (void) flag;
    *(header+1)=flag<<6 | *(header+1);
}

void set_retry(unsigned char *header, int flag)
{
    (void) header;
    (void) flag;
    *(header+1)=flag<<4 | *(header+1);
}

void set_more_data(unsigned char *header, int flag)
{
    (void) header;
    (void) flag;
    *(header+1)=flag<<2 | *(header+1);
}
