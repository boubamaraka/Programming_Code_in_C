#include <stdio.h>
#include <stdlib.h>
#include "bits.h"

/* Allocate memory for 8x8 table and returns pointer to the two-dimensional
 * array.
 */
char **allocTable(void)
{
    char **rows = malloc(8 * sizeof(char *));
    if (!rows)
        return NULL;
    for (unsigned int i = 0; i < 8; i++) {
        rows[i] = malloc(8 * sizeof(char));
    }
    return rows;
}

/* Frees memory of the two-dimensional array indicated in <s>
 */
void releaseTable(char **s)
{
    for (unsigned int i = 0; i < 8; i++) {
        free(s[i]);
    }
    free(s);
}

/* Prints the bits on table <s>, and the 8-bit values of each row and column.
 * Note that the function relies on having calculateRow and calculateColumn
 * implemented.
 */
void printTable(char **s)
{
    for (int y = 7; y >= 0; y--) {
        for (int x = 7; x >= 0; x--) {
            printf("%3d", s[y][x]);
        }
        printf(" %02x\n", calculateRow(s, y));
    }
    for (int x = 7; x >= 0; x--) {
        printf(" %02x", calculateColumn(s, x));
    }
    printf("\n");
}

/* Exercise 4.4.a: calculate the 8-bit number represented by row <idx> in
 * table <s>.
 * Returns: the number represented by the bits.
 */
unsigned char calculateRow(char **s, int idx)
{
    (void) s;
    (void) idx;
    int i=7;
    unsigned char value=0;
    while(i>=0){
        value=value | s[idx][i]<<i;
        i--;
      
    }
    return value; // replace this
}

/* Exercise 4.4.a: calculate the 8-bit number represented by column <idx> in
 * table <s>.
 * Returns: the number represented by the bits.
 */
unsigned char calculateColumn(char **s, int idx)
{
     int i=7;
    unsigned char value=0;
    while(i>=0){
        value=value | s[i][idx]<<i;
        i--;
      
    }
    return value; // replace this
}

/* Exercise 4.4.b: set the bits on row <idx> in table <s> to represent
 * <value>.
 */
void setRow(char **s, int idx, unsigned char value)
{
    (void) s;
    (void) idx;
    (void) value;
     int i=7;
    
    while(i>=0){
        if(value & (1<<i))
         s[idx][i]=1;
        else
             s[idx][i]=0;
        i--;
      
    }
    
}

/* Exercise 4.4.b: set the bits on column <idx> in table <s> to represent
 * <value>.
 */
void setColumn(char **s, int idx, unsigned char value)
{
    (void) s;
    (void) idx;
    (void) value;
    int i=7;
    
    while(i>=0){
        if(value & (1<<i))
         s[i][idx]=1;
        else
             s[i][idx]=0;
        i--;
      
    }
}
