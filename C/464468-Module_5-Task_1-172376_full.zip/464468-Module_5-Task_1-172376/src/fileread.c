#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "fileread.h"

/* Prints the given file as text on the screen.
 * Only printable characters are shown. Non-printable characters are printed
 * as '?'. <filename> parameter is the name of the file.
 * 
 * Returns the number of characters read
 */
int textdump(const char *filename) {
    (void) filename;
    FILE *file;
    char ch;
    char ch1 = '?';
    int counter = 0;
    file = fopen(filename, "r");
    if (file==NULL) {
         
        return  -1;
    } 
     if (feof(file)) {
        fprintf(stderr, "prematurely reached end of file\n");
        return 0;
    } 
        
    else{  while ( ( ch = fgetc(file) ) != EOF ) {
            
            counter++;
            if (isprint(ch))
                printf("%c", ch);
            else
                printf("%c", ch1);
        }
        
        
        fclose(file);
    }
    


    return counter;
}

/* Prints the given file as hexdump, at most 16 numbers per line.
 * <filename> parameter is the name of the file.
 * 
 * Returns the number of characters read
 */
int hexdump(const char *filename) {
    (void) filename;
    
    (void) filename;
    FILE *file;
    char ch;
    int c=0;
    
    int counter = 0;
    file = fopen(filename, "r");
    if (file==NULL) {
         
        return  -1;
    } 
     if (feof(file)) {
        fprintf(stderr, "prematurely reached end of file\n");
        return 0;
    } 
    else{  while ( ( ch = fgetc(file) ) != EOF ) {
            
            counter++;
            c++;
            
           // if(ch>0x10)
           
                printf("%02x ", ch);
           // else 
              //  printf("0X%02x ", ch);
            if (c==16){
            printf("\n");
            c=0;}
                
           
        }
        
        
        fclose(file);
    }
    
    return counter;
}
