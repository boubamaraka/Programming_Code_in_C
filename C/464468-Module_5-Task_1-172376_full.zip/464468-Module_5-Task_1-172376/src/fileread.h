#ifndef AALTO_FILEREAD_H
#define	AALTO_FILEREAD_H

int textdump(const char *filename);
int hexdump(const char *filename);

#endif	/* AALTO_ANYDATA_H */
