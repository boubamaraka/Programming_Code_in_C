#include "source.h"

int main()
{
    /* testing exercise 1.7 */
    printf("\n--- Exercise 1.7 ---\n");
    ascii_chart(28,38);
    
    /* testing exercise 1.8 */
    printf("\n--- Exercise 1.8 ---\n");
    secret_msg(0);
    secret_msg(1);
                
    return 0;
}
