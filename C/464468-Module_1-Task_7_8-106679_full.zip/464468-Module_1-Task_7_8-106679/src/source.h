#include <stdio.h>

extern char *msgs[10];

void ascii_chart(char min, char max);
float calculator(void);
void secret_msg(int msg);
