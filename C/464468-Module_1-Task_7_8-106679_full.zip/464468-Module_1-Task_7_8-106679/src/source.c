#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "source.h"

/* Don't touch the definition of msgs array! Checker uses this. */
char *msgs[10] = {
    "'6=*w+~)._", "J65+~5+~=0/*69,~+9;,9*~19++=79"
};

/* Exercise 1.7 */
void ascii_chart(char min, char max)
{  int dec;int num=0;
    
  for(int i=min;i<=max;i++)
  {  num=num+1;
        dec=isprint(i);
        if(dec==0)
            printf("%3d 0x%x ?",i,i);
        else
            printf("%3d 0x%x %c",i,i,i);
        if(num<4)
            printf("\t");
        if (num==4)
        { printf("\n");
        num=0;
        }
        
  }
  
}

char get_character(int msg, unsigned int cc) {
    if (msg >= 10 || !msgs[msg])
        return 0;

    if (strlen(msgs[msg]) <= cc)
        return 0;
    
    return msgs[msg][cc];
}

/* Exercise 1.8 */
void secret_msg(int msg)
{ char code;
int mes1,mes2;
for(code=0;;code++){
    mes1=get_character(msg, code);
    if(!mes1)
        break;
    mes2=158-mes1;
    printf("%c",mes2);
}
    
}
