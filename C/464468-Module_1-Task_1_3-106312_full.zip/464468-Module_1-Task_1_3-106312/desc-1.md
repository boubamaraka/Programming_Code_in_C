title: Simple connection
name: asdasdasd
date: 2014-11-26
task_id: 1.1

**Objective**: Test that your development environment works, and you
can return exercises to TMC. Get initial feeling of printf function.

Implement function three_lines (in source.c of the TMC exercise
template) that prints three lines in the following way. Also the last
line (March) should be followed by a new line:

    January
    February
    March
