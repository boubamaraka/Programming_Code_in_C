
void three_lines(void);
void simple_sum(void);
void simple_math(void);
