#include <stdio.h>
#include <math.h>
#include "source.h"

/* Exercise 1.1 */
void three_lines(void)
{  
    printf("January\nFebruary\nMarch\n");
}


/* Exercise 1.2 */
void simple_sum(void)
{  int num1,num2;
    scanf("%i%i",&num1,&num2);
    printf("%i + %i = %i\n",num1,num2,num1+num2);
}

/* Exercise 1.3 */
void simple_math(void)
{
    float num1,num2;
    char op;
    scanf("%f %c %f",&num1,&op,&num2);
        if(op =='-')
            printf("%.1f",num1-num2);
        else if(op=='+')
            printf("%.1f",num1+num2);
        else if(op=='*')
            printf("%.1f",num1*num2);
        else if(op=='/')
            printf("%.1f",num1/num2);
        else
            printf("ERR");
    
    
}
