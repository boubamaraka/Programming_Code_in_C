#include <stdlib.h>
#include "queue.h"
#include "queuepriv.h"
#include <string.h>

Queue *Queue_init(void)
{
    Queue *q = calloc(1, sizeof(Queue));
    return q;
}

int Queue_enqueue(Queue *q, const char *id, const char *name)
{
    (void) q;
    (void) id;
    (void) name;
    int len=strlen(name);
    int lenid=strlen(id);
    
 
   
   
    if(lenid>6)
        return 0;
   
    
          
    if(q->first==NULL)
    {    q->first=malloc(sizeof(struct student));
        q->first->name=malloc((len+1)*sizeof(char));
    strcpy(q->first->id,id);
    strcpy(q->first->name,name);
    q->last=q->first;
    q->last->next=NULL;
    }
    else
    {  
        q->last->next=malloc(sizeof(struct student));
       
        q->last->next->name=malloc((len+1)*sizeof(char));
         strcpy(q->last->next->id,id);
    strcpy(q->last->next->name,name);
   // q->last->next=q->last;
    
    q->last->next->next=NULL;
    q->last=q->last->next;
    }



    return 1;
}

char *Queue_firstID(Queue *q)
{
    if (q && q->first)
        return q->first->id;
    else
        return NULL;
}

char *Queue_firstName(Queue *q)
{
    if (q && q->first)
        return q->first->name;
    else
        return NULL;
}

int Queue_dequeue(Queue *q)
{
    (void) q;
    struct student *p=NULL;
    p=q->first;
    if(p!=NULL){
    if(q->first==q->last){ q->first=NULL;
    q->last=NULL;
    
     }
    else
    q->first=q->first->next;
            free(p->name);
            free(p);
    return 1;
    }
    return 0;
}

int Queue_drop(Queue *q, const char *id)
{
    (void) q;
    (void) id;
    struct student *p=q->first;
    struct student *p2=NULL;
    //struct student *p3=q->first->next;
    if (strlen(id)<=6){
    while(p!=NULL){
        if(strcmp(p->id,id)==0)
        { 
            if(p2==NULL){
                p2=q->first;
                q->first=p->next;
                free(p2->name);
                free(p2);
                return 1;
            }
             else if (p==q->last)
             {
                 q->last=p2;
                 q->last->next=NULL;
                 free(p->name);
                 free(p);
                 return 1;
             }
             else{ 
                 p2->next=p->next;
                 free(p->name);
                 free(p);
                 return 1;
             }
             }
        p2=p;
        p=p->next;
        }
    }
         
         
        
         
        
   
    return 0;
    
     
}

void Queue_delete(Queue *q)
{
    if (q) {
        while(Queue_dequeue(q));
        free(q);
    }
}
