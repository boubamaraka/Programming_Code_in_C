#include <stdlib.h>
#include "oodi.h"
#include<string.h>
#include <stdio.h>

/* Exercise 3.3.a: Initialize student record
 * 
 * Parameters:
 * or: Oodi record to be changed (does not need to be allocated)
 * p_student, p_course, p_grade, p_compdate: Values for different structure
 *      fields (must be copied)
 * 
 * Returns: 1 if initialization was succesful, 0 if it failed
 * If student ID is more than 6 characters, initialization fails.
 * 
 * -- Note that structure contains enough space for student ID, but not for
 * course name
 * -- Remember to check that reserved space is not overwritten
 */
int init_record(struct oodi *or, const char *p_student, const char *p_course,
        unsigned char p_grade, struct date p_date) {

    // or  = malloc(sizeof(struct oodi));
    // struct oodi* r = (struct oodi*)malloc(sizeof(struct oodi));


    int len2 = strlen(p_course);



    strcpy(or->student, p_student);


    or->course = (char*) malloc(len2 + 1 * sizeof (char));
    strcpy(or->course, p_course);
    or->grade = p_grade;
    or->compdate.day = p_date.day;
    or->compdate.month = p_date.month;
    or->compdate.year = p_date.year;
    int len = strlen(p_student);
    if (len <= 6)
        return 1;
    else
        return 0;


}

/* Exercise 3.3.b: Add a new record to a dynamic array.
 * (Resize the array as needed). All content of the new structure is copied.
 * 
 * Parameters:
 * array: start of an dynamic array (may be NULL, if array is empty)
 * length: current length of the array (number of entries)
 * newrec: new record to be added, all fields need to be copied.
 * 
 * Returns: pointer to the array after adding the new item
 */
struct oodi *add_record(struct oodi *array, unsigned int length, struct oodi newrec) {
    struct oodi * p;

    p = realloc(array, (length + 1) * sizeof (struct oodi));
    if (!p) {
        return array;
    }
    array = p;

    init_record((array + length), newrec.student, newrec.course, newrec.grade, newrec.compdate);
    // &array[length]




    return array;
}

/* Exercise 3.3.c: Change grade and date in existing record.
 * 
 * Parameters:
 * array: beginning of array
 * size: size of array
 * student: student ID to be changed
 * course: course to be changed
 * newgrade: new value for grade
 * newdate: new value for date
 * 
 * Returns: number of entries changed, i.e. either 1 or 0
 */
int change_grade(struct oodi *array, unsigned int size, const char *p_student,
        const char *p_course, unsigned char newgrade, struct date newdate)
{

    for (int i = 0; i < (int) size; i++) {
        int v1=strcmp(array[i].student,p_student);
        int v2=strcmp(array[i].course,p_course);
        if (v1==0 && v2==0) {
            array[i].grade = newgrade;
            array[i].compdate = newdate;
            return 1;
        }
    }

            return 0;
    
    
}

/* Exercise 3.3.d: Delete array (and all memory allocated for it)
 * 
 * Parameters:
 * array: beginning of the array
 * 
 * Returns: 1 when array is deleted
 */
int delete_array(struct oodi *array, unsigned int size) {
    for(int i=0;i<(int)size;i++)
    { free(array[i].course);
    }
    free(array);
    return 1;
}
