#include <stdio.h>
#include <math.h>
#include "source.h"

/* Exercise 1.1 */
void three_lines(void)
{
}


/* Exercise 1.2 */
void simple_sum(void)
{
}

/* Exercise 1.3 */
void simple_math(void)
{
}
