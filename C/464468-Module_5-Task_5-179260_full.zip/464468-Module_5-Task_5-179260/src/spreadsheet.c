#include <math.h>
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "spreadsheet.h"

const struct {
    char *name;
    double (*fptr)(Sheet *,Point, Point);
} functions[] = {
    { "sum", sumfunc },
    { "max", maxfunc },
    { "count", countfunc },
    { NULL, NULL }
};


/* 5.5.a: Creates a new spreadsheet with given dimensions.
 * Returns pointer to the allocated Sheet structure.
 */
Sheet *create_sheet(unsigned int xsize, unsigned int ysize)
{
   // (void) xsize;  // remove this line
   // (void) ysize;  // remove this line
    Sheet *or =malloc(sizeof(Sheet));
    unsigned int i,j;
    
     Cell **newcell=malloc((ysize )* sizeof(Cell *));
   
    for(j=0;j<ysize;j++){
       
        newcell[j]=malloc((xsize )* sizeof(Cell));
    
    for(i=0;i<xsize;i++){    
        newcell[j][i].type=UNSPEC;
    }
    }
      or->xsize=xsize;
    or->ysize=ysize;
    or->cells=newcell;
    return or;
}

/* 5.5.a: Releases the memory allocated for sheet.
 */
void free_sheet(Sheet *sheet)
{
    (void) sheet;  // remove this line
    unsigned int k;
    unsigned int  i=sheet->ysize;
    for(k=0;k<i;k++)
        free(sheet->cells[k]);
    free(sheet->cells);
    free (sheet);
}


/* 5.5.a: returns pointer to the Cell structure at given location <p>
 * in spreadsheet <sheet>.
 */
Cell *get_cell(Sheet *sheet, Point p)
{
    (void) sheet;  // remove this line
    (void) p;  // remove this line
    if((p.x>=sheet->xsize)||(p.y>=sheet->ysize))
    return NULL; // replace this line
    return &sheet->cells[p.y][p.x];
}

/* Convert two-letter user input into coordinates of type Point.
 */
Point get_point(char xc, char yc)
{
    Point p;
    p.x = toupper((int)xc) - 'A';
    p.y = toupper((int)yc) - 'A';
    return p;
}

/* Parses user input in <command> and applies it in spreadsheet <sheet>.
 * Returns 1 if input was valid, or 0 if it was not.
 */
int parse_command(Sheet *sheet, const char *command)
{
    double val;
    Point p;
    char xc, yc;
    int ret = sscanf(command, "%c%c %lf", &xc, &yc, &val);
    if (ret == 3) {
        p = get_point(xc, yc);
        set_value(sheet, p, val);
        return 1;
    }
    
    char func[10];
    Point ul, dr;
    char xc1, yc1, xc2, yc2;
    
    ret = sscanf(command, "%c%c %9s %c%c %c%c", &xc, &yc, func, &xc1, &yc1, &xc2, &yc2);
    if (ret == 7) {
        p = get_point(xc, yc);
        ul = get_point(xc1, yc1);
        dr = get_point(xc2, yc2);
        int i = 0;
        while (functions[i].name) {
            if (!strcmp(functions[i].name, func)) {
                set_func(sheet, p, functions[i].fptr, ul, dr);
                return 1;
            }
            i++;
        }
    }
    return 0;
}

/* Prints the content of given spreadsheet.
 */
void print_sheet(Sheet *sheet)
{
    printf("%-8c", ' ');
    for (unsigned int x = 0; x < sheet->xsize; x++) {
        printf("%-8c", 'A' + x);
    }
    fputs("\n", stdout);
    
    for (unsigned int y = 0; y < sheet->ysize; y++) {
        printf("%-8c", 'A' + y);
        for (unsigned int x = 0; x < sheet->xsize; x++) {
            Point p;
            p.x = x;
            p.y = y;
            Cell *c = get_cell(sheet, p);
            switch(c->type) {
                case VALUE:
                case FUNC:
                    printf("%-8.1f", eval_cell(sheet, p));
                    break;
                    
                default:
                    printf("%-8c", '*');
                    break;                    
            }
        }
        fputs("\n", stdout);
    }
}

/* 5.5.b: Set the content of location <p> in spreadsheet to constant <value>
 */
void set_value(Sheet *sheet, Point p, double value)
{
    (void) sheet;  // remove this line
    (void) p;  // remove this line
    (void) value;  // remove this line
   if((p.x>=sheet->xsize) || (p.y>=sheet->ysize)){
    } 
   else{
        sheet->cells[p.y][p.x].type = VALUE;
        sheet->cells[p.y][p.x].un.value=value;
        
    }
    // replace this line
}

/* 5.5.b: Set the content of location <p> in spreadsheet to given function.
 * <func> is pointer to the function. <ul> is the upper left corner and 
 * <dr> is the lower right corner of the area over which the function
 * is applied.
 */
void set_func(Sheet *sheet, Point p,
        double (*func)(Sheet *, Point, Point),
        Point ul, Point dr)
{
    if((p.x>=sheet->xsize) || (p.y>=sheet->ysize)){
    }
    else{
        sheet->cells[p.y][p.x].un.func.fptr= func;
        sheet->cells[p.y][p.x].un.func.downright = dr;
        sheet->cells[p.y][p.x].un.func.upleft = ul;
        sheet->cells[p.y][p.x].type = FUNC;
    }
    (void) sheet;  // remove this line
    (void) p;  // remove this line
    (void) func;  // remove this line
    (void) ul;  // remove this line
    (void) dr;  // remove this line
}

/* 5.5.c: Evaluate the content of cell at location <p>.
 * If cell is constant value, that is returned.
 * If cell contains function, the function is evaluated and its result returned.
 * If cell is unspecified or location out of bounds, NAN is returned.
 */
double eval_cell(Sheet *sheet, Point p)
{
    (void) sheet;  // remove this line
    (void) p;  // remove this line
    //return NAN;  // replace this line
   // unsigned int i,j;
   // for(j=0;j<p.y;j++){
        
    
   // for(i=0;i<p.x;i++){ 
        
        
        if ((p.x>=sheet->xsize)||(p.y>=sheet->ysize))
            return NAN;
        else{
            if(sheet->cells[p.y][p.x].type == VALUE)
            return  sheet->cells[p.y][p.x].un.value;
        if (sheet->cells[p.y][p.x].type == FUNC)
        { return sheet->cells[p.y][p.x].un.func.fptr(sheet, sheet->cells[p.y][p.x].un.func.upleft, sheet->cells[p.y][p.x].un.func.downright);
          //return val; 
            
    }
        }
    return NAN;
    
}

/* 5.5.d: Calculate the maximum value within area with upper left corner <ul>
 * and lower right corner <dl>, and return it.
 */
double maxfunc(Sheet *sheet, Point ul, Point dr)
{
    (void) sheet;  // remove this line
    (void) ul;  // remove this line
    (void) dr;  // remove this line
    double maxvalue=0;
    unsigned int i,j, x=sheet->xsize,y=sheet->ysize;
    i=ul.y;
    while(i<=dr.y && i< y){
        j=ul.x;
        while(j<=dr.x && j< x){
            if((sheet->cells[i][j].un.value)>maxvalue)
                maxvalue=sheet->cells[i][j].un.value;
             j++;   
        
        }
        i++;
    }
    
    return maxvalue;  // replace this line
}

/* 5.5.d: Calculate the sum of values within upper left corner <ul> and
 * lower right corner <dr>, and return the result.
 */
double sumfunc(Sheet *sheet, Point ul, Point dr)
{
    //(void) sheet;  // remove this line
    //(void) ul;  // remove this line
    //(void) dr;  // remove this line
    double sumvalue=0;
    unsigned int i,j, x=sheet->xsize,y=sheet->ysize;
    Point point;
    
    i=ul.y;
    while(i<=dr.y && i< y){
        j=ul.x;
        while(j<=dr.x && j< x){
            point.x=j;
            point.y=i;double value;
                value= eval_cell(sheet,point);
                if(!isnan(value))
                    sumvalue+=value;
                
                j++;
        }
        i++;
    }
    
    return sumvalue;
}

/* 5.5.d: count the number of specified cells inside the area with upper left
 * corner <ul> and lower right corner <dr>.
 */
double countfunc(Sheet *sheet, Point ul, Point dr)
{
    (void) sheet;  // remove this line
    (void) ul;  // remove this line
    (void) dr;  // remove this line
   double counter=0;
    unsigned int i,j, x=sheet->xsize,y=sheet->ysize;
    i=ul.y;
    while(i<=dr.y && i< y){
        j=ul.x;
        while(j<=dr.x && j< x){
            if((sheet->cells[i][j].type)!=UNSPEC)
                counter+=1;
            j++;
        }
        i++;
    }
    
    return counter;
}
