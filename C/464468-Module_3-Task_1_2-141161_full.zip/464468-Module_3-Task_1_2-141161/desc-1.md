title: Dynamic Array Reader
task_id: 3.1

**Objective:** Practice use of dynamic memory allocation with integer arrays

Implement function **dyn_reader** that reads a number of integers from
user. The function allocates the needed memory itself (instead of
getting the pointer to the memory buffer as a parameter). The array
consists of integers (int), and parameter n tells the number of
integers in the array. You can assume that the user types the right
number of valid integers. The function returns pointer to the array.
