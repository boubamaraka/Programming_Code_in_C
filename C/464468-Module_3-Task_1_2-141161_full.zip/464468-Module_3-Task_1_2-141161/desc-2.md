title: Add to array
task_id: 3.2

**Objective:** Practice use of realloc together with array
  manipulation.

Implement function **add_to_array** that adds a single integer to the
existing array of integers (**arr**). The length of the existing array
is **num**, and the new integer to be added is given in parameter
**newval**. Check that the function works correctly when called
several consecutive times.
