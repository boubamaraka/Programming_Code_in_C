#include <stdlib.h>
#include "source.h"
#include <stdio.h>


/* Exercise 3.1: Dynamic Array Reader */
/* Parameters:
 * n: Number of values to be read
 * 
 * Returns: pointer to the dynamically allocated array
 */
int *dyn_reader(unsigned int n)
{
    (void) n;
    int *p=malloc(n*sizeof(int));
    unsigned int i;
    for(i=0;i<n;i++)
    {  scanf("%d",&p[i]);
    }
     
    
    
    return p;  // replace this
}

/* Exercise 3.2: Add to array */
/* Parameters:
 * arr: Existing array of integers
 * num: number of integers in the array before the call
 * newval: new value to be added
 * 
 * Returns: pointer to the allocated array
 */
int *add_to_array(int *arr, unsigned int num, int newval)
{
    (void) arr;
    (void) num;
    (void) newval;
    int *p=realloc(arr,(num+1)*sizeof(int));
   
       
    
    unsigned int i;
    for (i=0;i<num;i++)
    {
        
             p[num]=newval;
    }
   
       
      
    return p;  // replace this
}
